<?php

/**
 * Paytm JsCheckout integration.
 *
 * @since 1.0.0
 */
require_once(__DIR__.'/includes/PaytmHelper.php');
require_once(__DIR__.'/includes/PaytmChecksum.php');

add_action('init', 'paytm_donation_response');


function paytm_donation_response()
{

	if (isset($_GET['paytmcallback']) && $_GET['paytmcallback']=="true") 
	{
		if(isset($_POST) && count($_POST)>0)
		{
			if(!empty($_POST['CHECKSUMHASH'])){
				$post_checksum = $_POST['CHECKSUMHASH'];
				unset($_POST['CHECKSUMHASH']);	
			}else{
				$post_checksum = "";
			}
			$order = array();
			$key = getMerchantKey($_POST['ORDERID']);

			$isValidChecksum = PaytmChecksum::verifySignature($_POST, $key['key'], $post_checksum);
			if($isValidChecksum === true)
			{
				$responseDescription = (!empty($_POST['RESPMSG'])) ? $_POST['RESPMSG'] :"";
				if($_POST['STATUS'] == 'TXN_SUCCESS') {
					$payment_meta=array();
					$payment_meta['payment_type']        = 'paytm_jscheckout';
					$payment_meta['payment_total']       = $_POST['TXNAMOUNT'];
					$payment_meta['payment_currency']    = 'INR';
					$payment_meta['payment_transaction'] = $_POST['TXNID'];
					$payment_meta['payment_mode'] = 	'';
					$payment_meta['payment_subscription'] = 	'';
					$payment_meta['payment_customer'] = 	'';
					$payment_meta['payment_period'] = 	'';
					$payment_meta['payment_note']        = 'TXNID: '.$_POST['TXNID'];

					wpforms()->entry->update(
						$_POST['ORDERID'],
						array(
							'status' => 'completed',
							'type'   => 'payment',
							'meta'   => wp_json_encode( $payment_meta ),
						),
						'',
						'',
						array( 'cap' => false )
					);
					$class = "wpforms-confirmation-container-full wpforms-confirmation-scroll";
					echo '<script>window.onload = function messageFunction() {
						document.getElementById("wpforms-'.$key['formId'].'").innerHTML="<div class='.$class.'><p>Thanks for contacting us! We will be in touch with you shortly.Your Transaction is successfull.</p></div>";
					}
					</script>';
				}else if($_POST['STATUS'] == 'PENDING'){
					$error = esc_html__( 'Payment Pending: '.$responseDescription.'', 'wpforms-paytm-jscheckout' );
				}else{
					$error = esc_html__( 'Payment Failed: '.$responseDescription.'', 'wpforms-paytm-jscheckout' );
				}
				
			}else{
				$error = esc_html__( 'Payment failed: Checksum mismatch error', 'wpforms-paytm-jscheckout' );
			}

			// If there was an error, log and update the payment status.
				if ( ! empty( $error ) ) {
					$payment_meta['payment_note'] = $error;
					// wpforms_log(
					// 	esc_html__( 'Paytm JsCheckout Error', 'wpforms-paytm-jscheckout' ),
					// 	sprintf( '%s - data: %s', $error, '<pre>' . print_r( $data, true ) . '</pre>' ),
					// 	array(
					// 		'parent'  => $_POST['ORDERID'],
					// 		'type'    => array( 'error', 'payment' ),
					// 		//'form_id' => $payment->form_id,
					// 	)
					// );
					wpforms()->entry->update(
						$_POST['ORDERID'],
						array(
							'status' => 'failed',
							'meta'   => wp_json_encode( $payment_meta ),
						),
						'',
						'',
						array( 'cap' => false )
					);
					$class = "wpforms-confirmation-container-full wpforms-confirmation-scroll";
					echo '<script>window.onload = function messageFunction() {
						document.getElementById("wpforms-'.$key['formId'].'").innerHTML="<div class='.$class.'><p>Thanks for contacting us! We will be in touch with you shortly.Your Transaction has failed.</p></div>";						
					}
					</script>';
					
					return;
				}
			// Completed Payment
			//return;
			//do_action( 'wpforms_paytm_jscheckout_process_complete', wpforms_decode( $payment->fields ), $form_data, $payment_id, $data );

			return;		
		}	
	}
	return;
}
class WPForms_Paytm_JsCheckout extends WPForms_Payment {

	/**
	 * Initialize.
	 *
	 * @since 1.0.0
	 */
	public function init() {

		$this->version  = WPFORMS_PAYTM_JSCHECKOUT_VERSION;
		$this->name     = 'Paytm JsCheckout';
		$this->slug     = 'paytm_jscheckout';
		$this->priority = 10;
		$this->icon     = plugins_url( 'assets/images/logo.jpg', __FILE__ );

		add_action( 'wpforms_process_complete', [ $this, 'process_entry' ], 40, 4 );
		add_action( 'wpforms_form_settings_notifications_single_after', [ $this, 'notification_settings' ], 10, 2 );
		add_filter( 'wpforms_entry_email_process', [ $this, 'process_email' ], 70, 5 );
	}

	/**
	 * Display content inside the panel content area.
	 *
	 * @since 1.0.0
	 */
	public function builder_content() {

		/*
		if ( ! is_ssl() ) {
			// Don't need this quite yet.
			echo '<div class="wpforms-alert wpforms-alert-warning">' . esc_html__( 'For Paytm IPN verification to successfully complete, your site must have an SSL certificate.', 'wpforms-paytm-jscheckout' ) . '</div>';
		}
		*/

		wpforms_panel_field(
			'checkbox',
			$this->slug,
			'enable',
			$this->form_data,
			esc_html__( 'Enable Paytm payments', 'wpforms-paytm-jscheckout' ),
			array(
				'parent'  => 'payments',
				'default' => '0',
			)
		);
		wpforms_panel_field(
			'text',
			$this->slug,
			'merchantid',
			$this->form_data,
			esc_html__( 'Paytm Merchant Id', 'wpforms-paytm-jscheckout' ),
			array(
				'parent'  => 'payments',
				'tooltip' => esc_html__( 'Enter your Paytm Merchant Id', 'wpforms-paytm-jscheckout' ),
			)
		);
		wpforms_panel_field(
			'text',
			$this->slug,
			'merchantkey',
			$this->form_data,
			esc_html__( 'Paytm Merchant Key', 'wpforms-paytm-jscheckout' ),
			array(
				'parent'  => 'payments',
				'tooltip' => esc_html__( 'Enter your Paytm Merchant Key', 'wpforms-paytm-jscheckout' ),
			)
		);
		wpforms_panel_field(
			'text',
			$this->slug,
			'website',
			$this->form_data,
			esc_html__( 'Paytm Merchant Website', 'wpforms-paytm-jscheckout' ),
			array(
				'parent'  => 'payments',
				'tooltip' => esc_html__( 'Enter your Paytm Merchant Website', 'wpforms-paytm-jscheckout' ),
			)
		);
		wpforms_panel_field(
			'text',
			$this->slug,
			'channel',
			$this->form_data,
			esc_html__( 'Paytm Channel', 'wpforms-paytm-jscheckout' ),
			array(
				'parent'  => 'payments',
				'tooltip' => esc_html__( 'Enter your Paytm Channel', 'wpforms-paytm-jscheckout' ),
			)
		);
		wpforms_panel_field(
			'text',
			$this->slug,
			'type',
			$this->form_data,
			esc_html__( 'Paytm Industry Type', 'wpforms-paytm-jscheckout' ),
			array(
				'parent'  => 'payments',
				'tooltip' => esc_html__( 'Enter your Paytm Industry Type', 'wpforms-paytm-jscheckout' ),
			)
		);
		
		wpforms_panel_field(
			'select',
			$this->slug,
			'mode',
			$this->form_data,
			esc_html__( 'Mode', 'wpforms-paytm-jscheckout' ),
			array(
				'parent'  => 'payments',
				'default' => 'staging',
				'options' => array(
					'production' => esc_html__( 'Production', 'wpforms-paytm-jscheckout' ),
					'staging'       => esc_html__( 'Staging', 'wpforms-paytm-jscheckout' ),
				),
				'tooltip' => esc_html__( 'Select Mode', 'wpforms-paytm-jscheckout' ),
			)
		);
		// wpforms_panel_field(
		// 	'select',
		// 	$this->slug,
		// 	'transaction',
		// 	$this->form_data,
		// 	esc_html__( 'Payment Type', 'wpforms-paytm-jscheckout' ),
		// 	array(
		// 		'parent'  => 'payments',
		// 		'default' => 'product',
		// 		'options' => array(
		// 			'product'  => esc_html__( 'Products and Services', 'wpforms-paytm-jscheckout' ),
		// 			'donation' => esc_html__( 'Donation', 'wpforms-paytm-jscheckout' ),
		// 		),
		// 		'tooltip' => esc_html__( 'Select the type of payment you are receiving.', 'wpforms-paytm-jscheckout' ),
		// 	)
		// );
	
		if ( function_exists( 'wpforms_conditional_logic' ) ) {
			wpforms_conditional_logic()->conditionals_block(
				array(
					'form'        => $this->form_data,
					'type'        => 'panel',
					'panel'       => 'paytm_jscheckout',
					'parent'      => 'payments',
					'actions'     => array(
						'go'   => esc_html__( 'Process', 'wpforms-paytm-jscheckout' ),
						'stop' => esc_html__( 'Don\'t process', 'wpforms-paytm-jscheckout' ),
					),
					'action_desc' => esc_html__( 'this charge if', 'wpforms-paytm-jscheckout' ),
					'reference'   => esc_html__( 'Paytm JsCheckout payment', 'wpforms-paytm-jscheckout' ),
				)
			);
		} else {
			echo
				'<p class="note">' .
				sprintf(
					wp_kses(
						/* translators: %s - Addons page URL in admin area. */
						__( 'Install the <a href="%s">Conditional Logic addon</a> to enable conditional logic for Paytm JsCheckout payments.', 'wpforms-paytm-jscheckout' ),
						array(
							'a' => array(
								'href' => array(),
							),
						)
					),
					admin_url( 'admin.php?page=wpforms-addons' )
				) .
				'</p>';
		}
	}

	/**
	 * Process and submit entry to provider.
	 *
	 * @since 1.0.0
	 *
	 * @param array $fields
	 * @param array $entry
	 * @param array $form_data
	 * @param int   $entry_id
	 */
	public function process_entry( $fields, $entry, $form_data, $entry_id ) {
		// TODO: start actually using this variable or remove it.
		$error = false;

		// Check an entry was created and passed.
		if ( empty( $entry_id ) ) {
			return;
		}

		// Check if payment method exists.
		if ( empty( $form_data['payments'][ $this->slug ] ) ) {
			return;
		}

		// Check required payment settings.
		$payment_settings = $form_data['payments'][ $this->slug ];
		if (
			empty( $payment_settings['merchantkey'] ) ||
			empty( $payment_settings['enable'] ) ||
			$payment_settings['enable'] != '1'
		) {
			return;
		}

		// If preventing the notification, log it, and then bail.
		if ( ! $this->is_conditional_logic_ok( $form_data, $fields ) ) {
			wpforms_log(
				esc_html__( 'Paytm JsCheckout Payment stopped by conditional logic', 'wpforms-paytm-jscheckout' ),
				$fields,
				[
					'parent'  => $entry_id,
					'type'    => [ 'payment', 'conditional_logic' ],
					'form_id' => $form_data['id'],
				]
			);

			return;
		}

		// Check that, despite how the form is configured, the form and
		// entry actually contain payment fields, otherwise no need to proceed.
		$form_has_payments  = wpforms_has_payment( 'form', $form_data );
		$entry_has_paymemts = wpforms_has_payment( 'entry', $fields );
		if ( ! $form_has_payments || ! $entry_has_paymemts ) {
			$error = esc_html__( 'Paytm JsCheckout Payment stopped, missing payment fields', 'wpforms-paytm-jscheckout' );
		}

		// Check total charge amount.
		$amount = wpforms_get_total_payment( $fields );
		if ( empty( $amount ) || $amount == wpforms_sanitize_amount( 0 ) ) {
			$error = esc_html__( 'Paytm JsCheckout Payment stopped, invalid/empty amount', 'wpforms-paytm-jscheckout' );
		}
		if ( $error ) {
			return;
		}
		// Update entry to include payment details.
		$entry_data = array(
			'status' => 'pending',
			'type'   => 'payment',
			'meta'   => wp_json_encode(
				array(
					'payment_type'      => $this->slug,
					'payment_recipient' =>  $payment_settings['merchantid'] ,
					'payment_total'     => $amount,
					'payment_currency'  => 'INR',
					'payment_mode'      => esc_html( $payment_settings['mode'] ),
				)
			),
		);
		
		wpforms()->entry->update( $entry_id, $entry_data, '', '', array( 'cap' => false ) );
		// Build the return URL with hash.
		$query_args  = 'form_id=' . $form_data['id'] . '&entry_id=' . $entry_id . '&hash=' . wp_hash( $form_data['id'] . ',' . $entry_id );
		$return_url = get_permalink()."?paytmcallback=true";
		
		// Setup various vars.
		$items       = wpforms_get_payment_items( $fields );
		$cancel_url  = ! empty( $payment_settings['cancel_url'] ) ? esc_url_raw( $payment_settings['cancel_url'] ) : home_url();
		//$cancel_url  = home_url();
		//$transaction = 'donation' === $payment_settings['transaction'] ? '_donations' : '_cart';
			// Combine a donation name from all payment fields names.
			$item_names = array();

			foreach ( $items as $item ) {

				if (
					! empty( $item['value_choice'] ) &&
					in_array( $item['type'], array( 'payment-multiple', 'payment-select', 'payment-checkbox' ), true )
				) {
					$item['value_choice'] = ( 'payment-checkbox' === $item['type'] ) ? str_replace( "\r\n", ', ', $item['value_choice'] ) : $item['value_choice'];
					$item_name            = $item['name'] . ' - ' . $item['value_choice'];
				} else {
					$item_name = $item['name'];
				}

				$item_names[] = stripslashes_deep( html_entity_decode( $item_name, ENT_COMPAT, 'UTF-8' ) );
			}

			$paytm_args['item_name'] = implode( '; ', $item_names );
			//$paytm_args['amount']    = $amount;
		//}

		// Last change to filter args.
		//$paytm_args = apply_filters( 'wpforms_paytm_redirect_args', $paytm_args, $fields, $form_data, $entry_id );

		get_header();
		/* body parameters */
		$paytmParams["body"] = array(
			"requestType" => "Payment",
			"mid" => $payment_settings['merchantid'],
			"websiteName" => $payment_settings['website'],
			"orderId" => absint( $entry_id ),
			"callbackUrl" => $return_url,
			"txnAmount" => array(
				"value" => $amount,
				"currency" => "INR",
			),
			"userInfo" => array(
				"custId" => 1,
			),
		);
		//echo "<pre>";print_r($paytmParams);die;	
		$checksum = PaytmChecksum::generateSignature(json_encode($paytmParams['body'], JSON_UNESCAPED_SLASHES),trim(get_option('paytm_merchant_key')));
		$paytmParams["head"] = array(
			"signature"	=> $checksum
		);
		if($payment_settings['mode'] =="production"){
			$mode =1;			
		}else{
			$mode = 0;			
		}
		$checkoutjs   = str_replace('MID',$payment_settings["merchantid"],getPaytmURL(PaytmConstants::CHECKOUT_JS_URL, $mode));
		
		$apiURL = getPaytmURL('theia/api/v1/initiateTransaction/',$mode) . '?mid='. $payment_settings['merchantid'].'&orderId='.absint( $entry_id );
		
		$postData = json_encode($paytmParams, JSON_UNESCAPED_SLASHES);
		$response = executecUrl($apiURL, $postData);
		echo '<style>#paytm-pg-spinner {
			    width: 70px;
			    text-align: center;
			    z-index: 999999;
			    position: fixed;
			    top: 25%;
			    left: 50%;
			}
			#paytm-pg-spinner>div {
			    width: 10px;
			    height: 10px;
			    background-color: #012b71;
			    border-radius: 100%;
			    display: inline-block;
			    -webkit-animation: sk-bouncedelay 1.4s infinite ease-in-out both;
			    animation: sk-bouncedelay 1.4s infinite ease-in-out both;
			}

			#paytm-pg-spinner .bounce1 {
			    -webkit-animation-delay: -0.64s;
			    animation-delay: -0.64s;
			}

			#paytm-pg-spinner .bounce2 {
			    -webkit-animation-delay: -0.48s;
			    animation-delay: -0.48s;
			}

			#paytm-pg-spinner .bounce3 {
			    -webkit-animation-delay: -0.32s;
			    animation-delay: -0.32s;
			}

			#paytm-pg-spinner .bounce4 {
			    -webkit-animation-delay: -0.16s;
			    animation-delay: -0.16s;
			}

			#paytm-pg-spinner .bounce4,
			#paytm-pg-spinner .bounce5 {
			    background-color: #48baf5;
			}

			@-webkit-keyframes sk-bouncedelay {
			    0%,
			    80%,
			    100% {
			        -webkit-transform: scale(0)
			    }
			    40% {
			        -webkit-transform: scale(1.0)
			    }
			}

			@keyframes sk-bouncedelay {
			    0%,
			    80%,
			    100% {
			        -webkit-transform: scale(0);
			        transform: scale(0);
			    }
			    40% {
			        -webkit-transform: scale(1.0);
			        transform: scale(1.0);
			    }
			}
			.paytm-overlay {
			    width: 100%;
			    position: fixed;
			    top: 0px;
			    left: 0px;
			    opacity: .3;
			    height: 100%;
			    background: #000;
			    z-index: 9999;
			}
			.paytm-woopg-loader p {
			    font-size: 10px !important;
			}
			.paytm-woopg-loader a {
			    font-size: 15px !important;
			}
			.refresh-payment {
			    display: inline;
			    margin-right: 20px;
			    width: 100px;
			    background: rgb(0, 185, 245);
			    padding: 10px 15px;
			    border-radius: 5px;
			    color: #fff;
			    text-decoration: none;
			}
			#paytm-checkoutjs {
			    display: block !important;
			}
			.paytm-action-btn{display: block;padding: 25px;}</style><div id="paytm-pg-spinner" class="paytm-woopg-loader"><div class="bounce1"></div><div class="bounce2"></div><div class="bounce3"></div><div class="bounce4"></div><div class="bounce5"></div><p class="loading-paytm">Loading Paytm...</p></div><div class="paytm-overlay paytm-woopg-loader"></div><div class="paytm-action-btn"></div>
			<script type="application/javascript">
			 function invokeBlinkCheckoutPopup(){
				 console.log("method called");
				 var config = {
					 "root": "",
					 "flow": "DEFAULT",
					 "data": {
					   "orderId": "'.absint( $entry_id ).'", 
					   "token": "'.$response["body"]["txnToken"].'", 
					   "tokenType": "TXN_TOKEN",
					   "amount": "'.$amount.'"
					 },
					 "handler": {
					   "notifyMerchant": function(eventName,data){
						 console.log("notifyMerchant handler function called");
						 if(eventName=="APP_CLOSED")
						 {
							window.history.back();
						 }
					   } 
					 }
				   };
			 
				   if(window.Paytm && window.Paytm.CheckoutJS){
					   window.Paytm.CheckoutJS.onLoad(function excecuteAfterCompleteLoad() {
						   window.Paytm.CheckoutJS.init(config).then(function onSuccess() {
							   window.Paytm.CheckoutJS.invoke();
						   }).catch(function onError(error){
							   console.log("error => ",error);
						   });
					   });
				   } 
			 }
			 </script><script type="application/javascript" crossorigin="anonymous" src="'.$checkoutjs.'" onload="invokeBlinkCheckoutPopup();"></script>
			';
		get_footer();
		exit;
	}

	/**
	 * Check if conditional logic check passes for the given settings.
	 *
	 * @since 1.4.0
	 *
	 * @param array $form_data Form data.
	 * @param array $fields    Form fields.
	 *
	 * @return bool
	 */
	private function is_conditional_logic_ok( $form_data, $fields ) {

		// Check for conditional logic.
		if (
			empty( $form_data['payments']['paytm_jscheckout']['conditional_logic'] ) &&
			empty( $form_data['payments']['paytm_jscheckout']['conditional_type'] ) &&
			empty( $form_data['payments']['paytm_jscheckout']['conditionals'] )
		) {
			return true;
		}

		// All conditional logic checks passed, continue with processing.
		$process = wpforms_conditional_logic()->conditionals_process( $fields, $form_data, $form_data['payments']['paytm_jscheckout']['conditionals'] );

		if ( $form_data['payments']['paytm_jscheckout']['conditional_type'] === 'stop' ) {
			$process = ! $process;
		}

		return $process;
	}

	
	/**
	 * Unset non Paytm notifications before process.
	 *
	 * @since 1.4.0
	 *
	 * @param array $form_data Form data.
	 *
	 * @return array
	 */
	private function unset_non_paytm_notifications( $form_data ) {

		if ( empty( $form_data['settings']['notifications'] ) ) {
			return $form_data;
		}

		foreach ( $form_data['settings']['notifications'] as $id => $notification ) {
			if ( empty( $notification['paytm_jscheckout'] ) ) {
				unset( $form_data['settings']['notifications'][ $id ] );
			}
		}

		return $form_data;
	}

	/**
	 * Add checkbox to form notification settings.
	 *
	 * @since 1.4.0
	 *
	 * @param \WPForms_Builder_Panel_Settings $settings WPForms_Builder_Panel_Settings class instance.
	 * @param int                             $id       Subsection ID.
	 */
	public function notification_settings( $settings, $id ) {

		wpforms_panel_field(
			'checkbox',
			'notifications',
			'paytm_jscheckout',
			$settings->form_data,
			esc_html__( 'Enable for Paytm JsCheckout completed payments', 'wpforms-paytm-jscheckout' ),
			[
				'parent'      => 'settings',
				'class'       => empty( $settings->form_data['payments']['paytm_jscheckout']['enable'] ) ? 'wpforms-hidden' : '',
				'input_class' => 'wpforms-radio-group wpforms-radio-group-' . $id . '-notification-by-status wpforms-radio-group-item-paytm_jscheckout wpforms-notification-by-status-alert',
				'subsection'  => $id,
				'tooltip'     => wp_kses(
					__( 'When enabled this notification will <em>only</em> be sent when a Paytm JsCheckout payment has been successfully <strong>completed</strong>.', 'wpforms-paytm-jscheckout' ),
					[
						'em'     => [],
						'strong' => [],
					]
				),
				'data'        => [
					'radio-group'    => $id . '-notification-by-status',
					'provider-title' => esc_html__( 'Paytm JsCheckout completed payments', 'wpforms-paytm-jscheckout' ),
				],
			]
		);
	}

	/**
	 * Logic that helps decide if we should send completed payments notifications.
	 *
	 * @since 1.4.0
	 *
	 * @param bool   $process         Whether to process or not.
	 * @param array  $fields          Form fields.
	 * @param array  $form_data       Form data.
	 * @param int    $notification_id Notification ID.
	 * @param string $context         The context of the current email process.
	 *
	 * @return bool
	 */
	public function process_email( $process, $fields, $form_data, $notification_id, $context ) {

		if ( ! $process ) {
			return false;
		}

		if ( empty( $form_data['payments']['paytm_jscheckout']['enable'] ) ) {
			return $process;
		}

		if ( empty( $form_data['settings']['notifications'][ $notification_id ]['paytm_jscheckout'] ) ) {
			return $process;
		}

		if ( ! $this->is_conditional_logic_ok( $form_data, $fields ) ) {
			return false;
		}

		return $context === 'paytm_jscheckout';
	}
}

new WPForms_Paytm_JsCheckout();
