For WPForms Paytm JsCheckout Version 1.0

## Requirements
	PHP Version >= 5.5
	WpForm Version >= 1.6
	
## Getting Started
1. Download the zip and add this to your plugin folder.
2. Enable the plugin from admin panel.
3. Now navigate WPforms >> All forms and select the form from which you want accept payments from paytm.
4. Now navigate to payments in form edit section.
5. Select Paytm JsCheckout Option.
6. Enter the credentials provided by paytm.
7. Check the checkbox to enable the gateway.
8. Now you are ready to accept payment with Paytm Gateway.


That's all folks!






